# ABA智能助手 - 公网部署指南

把项目部署到一台海外腾讯云 Linux 服务器（2核 4G+）上，通过 `http://<服务器IP>:8501` 对外提供服务。
登录系统已内置，每个家长注册自己的账号、看自己的孩子档案。

---

## 0. 先决条件

- 一台海外地域的腾讯云 Linux 服务器（建议 Ubuntu 22.04 / Debian 12）
- SSH 能登上去
- 已经准备好至少一个 AI API Key（MiniMax / OpenAI / Claude / 火山引擎任一）

## 1. 服务器初始化（只做一次）

SSH 登上服务器后执行：

```bash
# 1.1 装 Docker（官方一键脚本）
curl -fsSL https://get.docker.com | sudo sh

# 1.2 把当前用户加入 docker 组，免 sudo
sudo usermod -aG docker $USER
newgrp docker

# 1.3 验证
docker --version
docker compose version
```

## 2. 打开 8501 端口

到腾讯云控制台 → 你这台服务器 → 安全组 → 入站规则，加一条：

| 类型 | 协议 | 端口 | 来源 | 备注 |
|---|---|---|---|---|
| 自定义 | TCP | 8501 | 0.0.0.0/0 | ABA Streamlit |

> 想限制只让某几个 IP 访问，把"来源"改成你或家长的公网 IP 即可。

## 3. 把项目上传到服务器

有两种方式，选一种即可：

### 方式 A（推荐，最省事）：腾讯云网页文件上传

我已经把所有需要的文件打成了一个 141KB 的小包：`deploy/aba-assistant-deploy.tar.gz`

1. 腾讯云控制台 → 进入你的服务器实例 → 点"**登录**"按钮，选"标准登录"或"WebShell"打开网页终端
2. 在网页终端的工具栏找到**"上传文件"**按钮（不同界面位置略有差异，一般是右上角文件夹图标）
3. 选择本地的 `aba-assistant-deploy.tar.gz` 上传——默认会传到 `/root/` 或 `~/`
4. 在网页终端里执行：
   ```bash
   mkdir -p ~/AI_codex
   cd ~/AI_codex
   tar -xzf ~/aba-assistant-deploy.tar.gz    # 或 /root/aba-assistant-deploy.tar.gz
   ls                                         # 应该能看到 MVP_web/  知识库/  deploy/
   ```
5. 完成。后面用网页终端继续敲命令，或者切回 SSH 都行。

### 方式 B：本地命令行 rsync（适合你 SSH 已经能正常连）

在你本地（mac）项目根目录执行：

```bash
# 替换成你服务器的真实 IP 和用户
SERVER_IP=1.2.3.4
SERVER_USER=ubuntu

# 直接传那个打好的包，比 rsync 整个目录快
scp deploy/aba-assistant-deploy.tar.gz ${SERVER_USER}@${SERVER_IP}:~/

# 然后 SSH 上去解压
ssh ${SERVER_USER}@${SERVER_IP} 'mkdir -p ~/AI_codex && cd ~/AI_codex && tar -xzf ~/aba-assistant-deploy.tar.gz'
```

> 如果 SSH 报"REMOTE HOST IDENTIFICATION HAS CHANGED"，先到控制台核对服务器 SSH 指纹是否一致，确认后跑 `ssh-keygen -R <IP>` 清除旧 key 再重连。

## 4. 配 API Key

SSH 上服务器：

```bash
cd ~/AI_codex/MVP_web
cp .env.example .env
nano .env       # 把 MINIMAX_API_KEY 等改成真实的，DAILY_API_LIMIT 看预算调
```

`DAILY_API_LIMIT` 是全站每天总调用次数上限（默认 500），超出后所有用户会看到"今日已达上限"提示。这是兜底防滥用，不限制单用户。

## 5. 启动服务

```bash
cd ~/AI_codex
docker compose -f deploy/docker-compose.yml up -d --build
```

首次构建 5-10 分钟（拉依赖 + 装 chromadb）。完成后：

```bash
docker compose -f deploy/docker-compose.yml ps      # 看状态
docker compose -f deploy/docker-compose.yml logs -f # 看日志
```

容器健康后，浏览器打开：

```
http://<服务器IP>:8501
```

应该能看到登录界面。

## 6. 日常运维

```bash
# 重启
docker compose -f deploy/docker-compose.yml restart

# 停止
docker compose -f deploy/docker-compose.yml down

# 更新代码（本地改完 rsync 上去后）
docker compose -f deploy/docker-compose.yml up -d --build

# 看今天 API 用了多少次（也可以 cat 文件）
cat ~/AI_codex/deploy/data/api_counter.json

# 看实时日志
docker compose -f deploy/docker-compose.yml logs -f --tail=200
```

数据全部在 `~/AI_codex/deploy/data/` 下：

- `users/` — 每个家长的孩子档案、进展、任务（已按 user_id 隔离）
- `chromadb/` — 知识库向量索引
- `api_counter.json` — 当日 API 调用次数

升级容器、删容器都不会动这个目录。**定期 `tar -czf backup-$(date +%F).tar.gz deploy/data` 备份就行**。

## 7. 后续：绑域名 + HTTPS

等你买了域名（任意，不需要备案因为是海外服务器）：

1. 把域名 A 记录指到服务器 IP
2. 在服务器装 Nginx + certbot
3. 配置反向代理（必须开 WebSocket 支持，Streamlit 走 ws）：

   ```nginx
   server {
     server_name your.domain.com;
     location / {
       proxy_pass http://127.0.0.1:8501;
       proxy_http_version 1.1;
       proxy_set_header Upgrade $http_upgrade;
       proxy_set_header Connection "upgrade";
       proxy_set_header Host $host;
       proxy_set_header X-Real-IP $remote_addr;
       proxy_read_timeout 86400;
     }
   }
   ```

4. `sudo certbot --nginx -d your.domain.com` 一键签发证书
5. 把腾讯云安全组的 8501 端口改成"只允许 127.0.0.1"，对外只暴露 80/443

这一步等你准备好域名时再做，本文档先到这里。

---

## 故障排查

| 现象 | 排查 |
|---|---|
| 浏览器打不开 | 1) `docker compose ps` 看容器是否 healthy；2) 安全组 8501 是否开放；3) `curl http://localhost:8501/_stcore/health` 在服务器本机能否通 |
| 登录后报"API 配置错误" | 检查 `.env` 里 API Key 是否填了，重启容器：`docker compose restart` |
| 容器一直 unhealthy | `docker compose logs --tail=200` 看启动报错；通常是依赖装失败或 8501 被占用 |
| 想完全重置数据 | `docker compose down && rm -rf deploy/data && docker compose up -d` |
