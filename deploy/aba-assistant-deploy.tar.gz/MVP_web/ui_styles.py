"""
====================================
ABA智能助手 - 样式美化模块
====================================

包含：
- 自定义CSS样式
- 主题颜色配置
- Streamlit样式增强
"""

THEME_COLORS = {
    "primary": "#4A90D9",
    "secondary": "#6C757D",
    "success": "#28A745",
    "warning": "#FFC107",
    "danger": "#DC3545",
    "info": "#17A2B8",
    "light": "#F8F9FA",
    "dark": "#343A40",
    "background": "#FFFFFF",
    "card_bg": "#F8F9FA",
    "border": "#DEE2E6",
}

CUSTOM_CSS = f"""
<style>
/* 全局样式 */
.stApp {{
    background-color: {THEME_COLORS["background"]};
}}

/* 标题样式 */
.main-header {{
    font-size: 2.5rem;
    font-weight: 700;
    color: {THEME_COLORS["primary"]};
    text-align: center;
    padding: 1rem 0;
    border-bottom: 3px solid {THEME_COLORS["primary"]};
    margin-bottom: 2rem;
}}

/* 卡片样式 */
.css-1r6slz0 {{
    background-color: {THEME_COLORS["card_bg"]};
    border-radius: 12px;
    padding: 1.5rem;
    box-shadow: 0 2px 8px rgba(0,0,0,0.1);
    border: 1px solid {THEME_COLORS["border"]};
}}

/* 按钮样式 */
.stButton > button {{
    background-color: {THEME_COLORS["primary"]};
    color: white;
    border-radius: 8px;
    padding: 0.5rem 1.5rem;
    font-weight: 600;
    border: none;
    transition: all 0.3s ease;
}}

.stButton > button:hover {{
    background-color: #3A7BC8;
    box-shadow: 0 4px 12px rgba(74, 144, 217, 0.4);
    transform: translateY(-2px);
}}

/* 成功按钮 */
.success-button > button {{
    background-color: {THEME_COLORS["success"]};
}}

/* 输入框样式 */
.stTextInput > div > div > input,
.stTextArea > div > div > textarea,
.stSelectbox > div > div > select {{
    border-radius: 8px;
    border: 2px solid {THEME_COLORS["border"]};
    padding: 0.75rem;
}}

.stTextInput > div > div > input:focus,
.stTextArea > div > div > textarea:focus {{
    border-color: {THEME_COLORS["primary"]};
    box-shadow: 0 0 0 3px rgba(74, 144, 217, 0.2);
}}

/* 选项卡样式 */
.stTabs [data-baseweb="tab-list"] {{
    gap: 1rem;
    background-color: {THEME_COLORS["light"]};
    padding: 0.5rem;
    border-radius: 12px;
}}

.stTabs [data-baseweb="tab"] {{
    border-radius: 8px;
    padding: 0.75rem 1.5rem;
    font-weight: 600;
}}

.stTabs [aria-selected="true"] {{
    background-color: {THEME_COLORS["primary"]} !important;
    color: white !important;
}}

/* 指标卡片样式 */
.stMetric {{
    background-color: white;
    border-radius: 12px;
    padding: 1.5rem;
    box-shadow: 0 2px 8px rgba(0,0,0,0.08);
    border-left: 4px solid {THEME_COLORS["primary"]};
}}

/* 展开器样式 */
.streamlit-expanderHeader {{
    background-color: {THEME_COLORS["card_bg"]};
    border-radius: 8px;
    font-weight: 600;
}}

/* 进度条样式 */
.stProgress > div > div > div {{
    background-color: {THEME_COLORS["primary"]};
}}

/* 成功/警告/错误消息样式 */
.stSuccess {{
    background-color: #D4EDDA;
    border-color: {THEME_COLORS["success"]};
    border-radius: 8px;
}}

.stWarning {{
    background-color: #FFF3CD;
    border-color: {THEME_COLORS["warning"]};
    border-radius: 8px;
}}

.stError {{
    background-color: #F8D7DA;
    border-color: {THEME_COLORS["danger"]};
    border-radius: 8px;
}}

/* 侧边栏样式 */
.css-1d391kg {{
    background-color: {THEME_COLORS["light"]};
}}

/* 表单样式 */
.stForm {{
    background-color: {THEME_COLORS["card_bg"]};
    border-radius: 12px;
    padding: 1.5rem;
    border: 1px solid {THEME_COLORS["border"]};
}}

/* 导航按钮组 */
.nav-button {{
    display: flex;
    gap: 0.5rem;
    margin-bottom: 1rem;
}}

/* 统计卡片 */
.stat-card {{
    background: white;
    border-radius: 12px;
    padding: 1.5rem;
    text-align: center;
    box-shadow: 0 2px 8px rgba(0,0,0,0.08);
    transition: transform 0.3s ease;
}}

.stat-card:hover {{
    transform: translateY(-5px);
    box-shadow: 0 4px 16px rgba(0,0,0,0.12);
}}

/* 标签样式 */
.tag {{
    display: inline-block;
    padding: 0.25rem 0.75rem;
    border-radius: 20px;
    font-size: 0.85rem;
    margin: 0.25rem;
}}

.tag-primary {{
    background-color: #E7F1FF;
    color: {THEME_COLORS["primary"]};
}}

.tag-success {{
    background-color: #D4EDDA;
    color: {THEME_COLORS["success"]};
}}

.tag-warning {{
    background-color: #FFF3CD;
    color: #856404;
}}

/* 分隔线 */
.custom-divider {{
    border-top: 2px dashed {THEME_COLORS["border"]};
    margin: 1.5rem 0;
}}

/* 页面标题 */
.page-title {{
    font-size: 1.8rem;
    font-weight: 700;
    color: {THEME_COLORS["dark"]};
    margin-bottom: 1.5rem;
    padding-bottom: 0.5rem;
    border-bottom: 2px solid {THEME_COLORS["primary"]};
}}

/* 副标题 */
.subtitle {{
    font-size: 1.2rem;
    color: {THEME_COLORS["secondary"]};
    margin-bottom: 1rem;
}}

/* 图表容器 */
.chart-container {{
    background: white;
    border-radius: 12px;
    padding: 1rem;
    box-shadow: 0 2px 8px rgba(0,0,0,0.08);
}}

/* 报告预览样式 */
.report-preview {{
    background: white;
    border-radius: 12px;
    padding: 2rem;
    box-shadow: 0 2px 12px rgba(0,0,0,0.1);
    border: 1px solid {THEME_COLORS["border"]};
}}

/* 隐藏默认的Streamlit元素 */
#MainMenu {{visibility: hidden;}}
footer {{visibility: hidden;}}
header {{visibility: hidden;}}

/* 进度指示器 */
.spinner {{
    display: flex;
    justify-content: center;
    align-items: center;
    padding: 2rem;
}}

/* 任务卡片样式 */
.task-card {{
    background: white;
    border-radius: 12px;
    padding: 1rem 1.25rem;
    margin-bottom: 0.75rem;
    box-shadow: 0 2px 8px rgba(0,0,0,0.08);
    border-left: 4px solid {THEME_COLORS["primary"]};
    transition: transform 0.2s ease;
}}

.task-card:hover {{
    transform: translateX(4px);
    box-shadow: 0 4px 12px rgba(0,0,0,0.12);
}}

.task-card.completed {{
    border-left-color: {THEME_COLORS["success"]};
    opacity: 0.85;
}}

.task-name {{
    font-size: 1.1rem;
    font-weight: 600;
    color: {THEME_COLORS["dark"]};
    margin-bottom: 0.5rem;
}}

.task-desc {{
    font-size: 0.9rem;
    color: {THEME_COLORS["secondary"]};
    margin-bottom: 0.5rem;
    line-height: 1.5;
}}

.task-meta {{
    font-size: 0.8rem;
    color: #888;
}}
</style>
"""


def apply_custom_styles():
    """应用自定义样式"""
    import streamlit as st
    st.markdown(CUSTOM_CSS, unsafe_allow_html=True)


def get_card_html(title, content, border_color=None):
    """生成卡片HTML"""
    border = border_color or THEME_COLORS["primary"]
    return f"""
    <div style="
        background: white;
        border-radius: 12px;
        padding: 1.5rem;
        box-shadow: 0 2px 8px rgba(0,0,0,0.08);
        border-left: 4px solid {border};
        margin: 1rem 0;
    ">
        <h4 style="margin: 0 0 1rem 0; color: {THEME_COLORS['dark']};">{title}</h4>
        <div>{content}</div>
    </div>
    """


def get_badge(text, badge_type="primary"):
    """生成徽章HTML"""
    colors = {
        "primary": ("#E7F1FF", THEME_COLORS["primary"]),
        "success": ("#D4EDDA", THEME_COLORS["success"]),
        "warning": ("#FFF3CD", "#856404"),
        "danger": ("#F8D7DA", THEME_COLORS["danger"]),
        "info": ("#D1ECF1", THEME_COLORS["info"]),
    }
    bg, color = colors.get(badge_type, colors["primary"])
    return f'<span style="background:{bg};color:{color};padding:0.25rem 0.75rem;border-radius:20px;font-size:0.85rem;margin:0.25rem;display:inline-block;">{text}</span>'


def get_progress_bar(percentage, color=None):
    """生成分隔线HTML"""
    bar_color = color or THEME_COLORS["primary"]
    return f"""
    <div style="background:#E9ECEF;border-radius:10px;height:10px;overflow:hidden;">
        <div style="width:{percentage}%;background:{bar_color};height:100%;border-radius:10px;"></div>
    </div>
    """
