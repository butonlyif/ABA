"""
====================================
ABA智能助手 - 深度记忆系统
====================================

完整的用户记忆解决方案：
- 用户登录/注册系统
- SQLite对话存储（无限历史）
- 自动语料提取
- Chroma向量数据库
- RAG检索增强
"""

import os
import json
import sqlite3
import hashlib
import uuid
from pathlib import Path
from datetime import datetime
from typing import Dict, List, Optional, Tuple
import threading

try:
    from config import USER_DATA_PATH
except ImportError:
    USER_DATA_PATH = "./data/users"

try:
    import chromadb
    from chromadb.config import Settings
    CHROMADB_AVAILABLE = True
except ImportError:
    CHROMADB_AVAILABLE = False
    print("⚠️ ChromaDB 未安装，向量功能将不可用")


class DeepMemorySystem:
    """深度记忆系统"""

    def __init__(self, data_path: str = USER_DATA_PATH):
        self.data_path = Path(data_path)

        if not self.data_path.exists():
            self.data_path.mkdir(parents=True, exist_ok=True)

        self.db_path = self.data_path / "memory.db"
        self.current_user_id: Optional[str] = None
        self.current_username: Optional[str] = None

        self._init_database()
        self._init_vector_store()

        if CHROMADB_AVAILABLE:
            self._init_chroma()
        else:
            self.chroma_client = None
            self.collection = None

    def _init_database(self):
        """初始化SQLite数据库"""
        conn = sqlite3.connect(str(self.db_path), check_same_thread=False)
        cursor = conn.cursor()

        cursor.execute("""
            CREATE TABLE IF NOT EXISTS users (
                user_id TEXT PRIMARY KEY,
                username TEXT UNIQUE NOT NULL,
                password_hash TEXT NOT NULL,
                created_at TEXT NOT NULL,
                last_login TEXT,
                user_info TEXT
            )
        """)

        cursor.execute("""
            CREATE TABLE IF NOT EXISTS conversations (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id TEXT NOT NULL,
                role TEXT NOT NULL,
                content TEXT NOT NULL,
                timestamp TEXT NOT NULL,
                is_extracted INTEGER DEFAULT 0,
                metadata TEXT,
                FOREIGN KEY (user_id) REFERENCES users(user_id)
            )
        """)

        cursor.execute("""
            CREATE TABLE IF NOT EXISTS extracted_corpus (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id TEXT NOT NULL,
                corpus_type TEXT NOT NULL,
                content TEXT NOT NULL,
                source_conversation_id INTEGER,
                created_at TEXT NOT NULL,
                embedding_id TEXT,
                FOREIGN KEY (user_id) REFERENCES users(user_id)
            )
        """)

        cursor.execute("""
            CREATE INDEX IF NOT EXISTS idx_conversations_user
            ON conversations(user_id, timestamp)
        """)

        cursor.execute("""
            CREATE INDEX IF NOT EXISTS idx_corpus_user
            ON extracted_corpus(user_id, corpus_type)
        """)

        conn.commit()
        conn.close()

    def _init_vector_store(self):
        """初始化向量存储目录"""
        self.vector_path = self.data_path / "vectors"
        self.vector_path.mkdir(parents=True, exist_ok=True)

    def _init_chroma(self):
        """初始化Chroma向量数据库"""
        try:
            self.chroma_client = chromadb.PersistentClient(
                path=str(self.vector_path),
                settings=Settings(anonymized_telemetry=False)
            )
            self.collection = self.chroma_client.get_or_create_collection(
                name="user_corpus",
                metadata={"description": "用户对话语料库"}
            )
        except Exception as e:
            print(f"⚠️ ChromaDB初始化失败: {e}")
            self.chroma_client = None
            self.collection = None
            CHROMADB_AVAILABLE = False

    def _hash_password(self, password: str) -> str:
        """密码哈希"""
        salt = "aba_assistant_salt_2024"
        return hashlib.sha256(f"{password}{salt}".encode()).hexdigest()

    def register(self, username: str, password: str) -> Tuple[bool, str]:
        """
        注册新用户

        Returns:
            (成功标志, 消息)
        """
        if len(username) < 2:
            return False, "用户名至少需要2个字符"

        if len(password) < 4:
            return False, "密码至少需要4个字符"

        conn = sqlite3.connect(str(self.db_path))
        cursor = conn.cursor()

        cursor.execute(
            "SELECT user_id FROM users WHERE username = ?",
            (username,)
        )
        if cursor.fetchone():
            conn.close()
            return False, "用户名已存在"

        user_id = str(uuid.uuid4())
        password_hash = self._hash_password(password)

        try:
            cursor.execute(
                """INSERT INTO users (user_id, username, password_hash, created_at)
                   VALUES (?, ?, ?, ?)""",
                (user_id, username, password_hash, datetime.now().isoformat())
            )
            conn.commit()
            conn.close()

            self.current_user_id = user_id
            self.current_username = username
            return True, "注册成功"
        except Exception as e:
            conn.close()
            return False, f"注册失败: {str(e)}"

    def login(self, username: str, password: str) -> Tuple[bool, str]:
        """
        用户登录

        Returns:
            (成功标志, 消息)
        """
        conn = sqlite3.connect(str(self.db_path))
        cursor = conn.cursor()

        password_hash = self._hash_password(password)

        cursor.execute(
            "SELECT user_id, username FROM users WHERE username = ? AND password_hash = ?",
            (username, password_hash)
        )
        result = cursor.fetchone()

        if result:
            cursor.execute(
                "UPDATE users SET last_login = ? WHERE user_id = ?",
                (datetime.now().isoformat(), result[0])
            )
            conn.commit()
            conn.close()

            self.current_user_id = result[0]
            self.current_username = result[1]
            return True, "登录成功"
        else:
            conn.close()
            return False, "用户名或密码错误"

    def logout(self):
        """登出"""
        self.current_user_id = None
        self.current_username = None

    def is_logged_in(self) -> bool:
        """检查是否已登录"""
        return self.current_user_id is not None

    def get_user_info(self) -> Optional[Dict]:
        """获取当前用户信息"""
        if not self.current_user_id:
            return None

        conn = sqlite3.connect(str(self.db_path))
        cursor = conn.cursor()

        cursor.execute(
            "SELECT username, created_at, last_login, user_info FROM users WHERE user_id = ?",
            (self.current_user_id,)
        )
        result = cursor.fetchone()
        conn.close()

        if result:
            user_info = {
                "username": result[0],
                "created_at": result[1],
                "last_login": result[2],
                "user_info": json.loads(result[3]) if result[3] else {}
            }
            return user_info
        return None

    def save_user_profile(self, profile: Dict):
        """保存用户资料"""
        if not self.current_user_id:
            return

        conn = sqlite3.connect(str(self.db_path))
        cursor = conn.cursor()

        cursor.execute(
            "UPDATE users SET user_info = ? WHERE user_id = ?",
            (json.dumps(profile, ensure_ascii=False), self.current_user_id)
        )
        conn.commit()
        conn.close()

    def save_conversation(
        self,
        role: str,
        content: str,
        metadata: Optional[Dict] = None
    ):
        """保存对话"""
        if not self.current_user_id:
            return

        conn = sqlite3.connect(str(self.db_path))
        cursor = conn.cursor()

        cursor.execute(
            """INSERT INTO conversations (user_id, role, content, timestamp, metadata)
               VALUES (?, ?, ?, ?, ?)""",
            (
                self.current_user_id,
                role,
                content,
                datetime.now().isoformat(),
                json.dumps(metadata, ensure_ascii=False) if metadata else None
            )
        )
        conversation_id = cursor.lastrowid
        conn.commit()
        conn.close()

        return conversation_id

    def get_conversation_history(
        self,
        limit: int = 100,
        offset: int = 0
    ) -> List[Dict]:
        """获取对话历史"""
        if not self.current_user_id:
            return []

        conn = sqlite3.connect(str(self.db_path))
        cursor = conn.cursor()

        cursor.execute(
            """SELECT id, role, content, timestamp, metadata
               FROM conversations
               WHERE user_id = ?
               ORDER BY timestamp DESC
               LIMIT ? OFFSET ?""",
            (self.current_user_id, limit, offset)
        )
        results = cursor.fetchall()
        conn.close()

        conversations = []
        for row in reversed(results):
            conversations.append({
                "id": row[0],
                "role": row[1],
                "content": row[2],
                "timestamp": row[3],
                "metadata": json.loads(row[4]) if row[4] else {}
            })
        return conversations

    def get_conversation_count(self) -> int:
        """获取对话总数"""
        if not self.current_user_id:
            return 0

        conn = sqlite3.connect(str(self.db_path))
        cursor = conn.cursor()

        cursor.execute(
            "SELECT COUNT(*) FROM conversations WHERE user_id = ?",
            (self.current_user_id,)
        )
        count = cursor.fetchone()[0]
        conn.close()
        return count

    def extract_corpus_from_conversations(self, agent=None) -> int:
        """
        从对话中自动提取语料

        Args:
            agent: AI agent实例，用于分析对话

        Returns:
            提取的语料数量
        """
        if not self.current_user_id:
            return 0

        if not CHROMADB_AVAILABLE or not self.collection:
            return 0

        conn = sqlite3.connect(str(self.db_path))
        cursor = conn.cursor()

        cursor.execute(
            """SELECT id, content FROM conversations
               WHERE user_id = ? AND is_extracted = 0
               ORDER BY timestamp""",
            (self.current_user_id,)
        )
        unextracted = cursor.fetchall()
        conn.close()

        if not unextracted:
            return 0

        extracted_count = 0

        for conv_id, content in unextracted:
            if len(content) < 20:
                continue

            corpus_items = self._analyze_and_extract(content, agent)

            for item in corpus_items:
                self._save_corpus_item(
                    corpus_type=item["type"],
                    content=item["content"],
                    source_conversation_id=conv_id
                )
                extracted_count += 1

            conn = sqlite3.connect(str(self.db_path))
            cursor = conn.cursor()
            cursor.execute(
                "UPDATE conversations SET is_extracted = 1 WHERE id = ?",
                (conv_id,)
            )
            conn.commit()
            conn.close()

        return extracted_count

    def _analyze_and_extract(
        self,
        content: str,
        agent=None
    ) -> List[Dict]:
        """
        分析对话内容并提取语料

        Args:
            content: 对话内容
            agent: AI agent

        Returns:
            提取的语料列表
        """
        corpus_items = []

        if agent and hasattr(agent, 'client') and agent.client:
            try:
                prompt = f"""分析以下对话内容，提取有价值的儿童发展相关信息：

{content[:1000]}

请提取以下类型的语料（每类最多3条）：
1. 儿童特征描述（行为、偏好、能力）
2. 有效的干预方法或策略
3. 家长关注的问题类型
4. 孩子的进步或变化

以JSON格式输出：
{{
  "corpus": [
    {{"type": "child_feature", "content": "..."}},
    {{"type": "effective_method", "content": "..."}},
    ...
  ]
}}"""

                response = agent.client.chat.completions.create(
                    model=agent.model_config.get("model", "MiniMax-M2.7"),
                    messages=[
                        {"role": "system", "content": "你是一个儿童发展信息提取专家。"},
                        {"role": "user", "content": prompt}
                    ],
                    max_tokens=500,
                    temperature=0.3
                )

                result_text = response.choices[0].message.content

                import re
                json_match = re.search(r'\{.*\}', result_text, re.DOTALL)
                if json_match:
                    data = json.loads(json_match.group())
                    corpus_items = data.get("corpus", [])
            except Exception as e:
                print(f"语料提取失败: {e}")

        if not corpus_items:
            keywords = ["孩子", "训练", "方法", "进步", "问题", "行为"]
            for kw in keywords:
                if kw in content:
                    corpus_items.append({
                        "type": "general",
                        "content": content[:200]
                    })
                    break

        return corpus_items

    def _save_corpus_item(
        self,
        corpus_type: str,
        content: str,
        source_conversation_id: Optional[int] = None
    ):
        """保存单条语料"""
        if not self.current_user_id:
            return

        if not CHROMADB_AVAILABLE or not self.collection:
            return

        embedding_id = f"{self.current_user_id}_{datetime.now().timestamp()}"

        conn = sqlite3.connect(str(self.db_path))
        cursor = conn.cursor()

        cursor.execute(
            """INSERT INTO extracted_corpus
               (user_id, corpus_type, content, source_conversation_id, created_at, embedding_id)
               VALUES (?, ?, ?, ?, ?, ?)""",
            (
                self.current_user_id,
                corpus_type,
                content,
                source_conversation_id,
                datetime.now().isoformat(),
                embedding_id
            )
        )
        corpus_id = cursor.lastrowid
        conn.commit()
        conn.close()

        try:
            self.collection.add(
                documents=[content],
                ids=[embedding_id],
                metadatas=[{
                    "user_id": self.current_user_id,
                    "corpus_type": corpus_type,
                    "corpus_id": corpus_id
                }]
            )
        except Exception as e:
            print(f"向量存储失败: {e}")

    def retrieve_relevant_corpus(
        self,
        query: str,
        top_k: int = 5
    ) -> List[Dict]:
        """
        检索相关语料（RAG核心）

        Args:
            query: 查询文本
            top_k: 返回数量

        Returns:
            相关语料列表
        """
        if not self.current_user_id:
            return []

        if not CHROMADB_AVAILABLE or not self.collection:
            return []

        try:
            results = self.collection.query(
                query_texts=[query],
                n_results=top_k,
                where={"user_id": self.current_user_id}
            )

            corpus_list = []
            if results and results.get("documents"):
                for i, doc in enumerate(results["documents"][0]):
                    corpus_list.append({
                        "content": doc,
                        "type": results["metadatas"][0][i].get("corpus_type", "unknown")
                    })
            return corpus_list

        except Exception as e:
            print(f"语料检索失败: {e}")
            return []

    def get_corpus_summary(self) -> Dict:
        """获取语料库摘要"""
        if not self.current_user_id:
            return {"total": 0, "by_type": {}}

        conn = sqlite3.connect(str(self.db_path))
        cursor = conn.cursor()

        cursor.execute(
            "SELECT COUNT(*) FROM extracted_corpus WHERE user_id = ?",
            (self.current_user_id,)
        )
        total = cursor.fetchone()[0]

        cursor.execute(
            """SELECT corpus_type, COUNT(*) as count
               FROM extracted_corpus
               WHERE user_id = ?
               GROUP BY corpus_type""",
            (self.current_user_id,)
        )
        type_counts = dict(cursor.fetchall())

        conn.close()

        return {
            "total": total,
            "by_type": type_counts
        }

    def get_context_for_rag(self, current_query: str) -> str:
        """
        获取RAG上下文字符串

        Args:
            current_query: 当前查询

        Returns:
            格式化的上下文字符串
        """
        corpus = self.retrieve_relevant_corpus(current_query, top_k=5)

        if not corpus:
            return ""

        context = "\n\n## 从历史对话中提取的相关信息：\n"
        for item in corpus:
            context += f"- [{item['type']}] {item['content']}\n"

        return context


memory_system = DeepMemorySystem()
