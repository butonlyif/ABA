# ====================================
# ABA智能助手 - 配置文件
# ====================================

import os
from pathlib import Path
from dotenv import load_dotenv

_env_file = Path(__file__).resolve().parent / ".env"
load_dotenv(dotenv_path=_env_file)

BASE_DIR = Path(__file__).resolve().parent


def _resolve_path(*candidates: str) -> str:
    """Return the first existing candidate path, falling back to the first one."""
    paths = [Path(candidate) for candidate in candidates]
    for path in paths:
        resolved = path if path.is_absolute() else BASE_DIR / path
        if resolved.exists():
            return str(resolved)
    fallback = paths[0]
    return str(fallback if fallback.is_absolute() else BASE_DIR / fallback)

# ====================================
# AI模型配置
# ====================================

# 支持的AI模型
AI_MODELS = {
    "minimax": {
        "name": "MiniMax-M2.7",
        "provider": "openai",
        "model": "MiniMax-M2.7",
        "api_key_env": "MINIMAX_API_KEY",
        "base_url": "https://api.minimaxi.com/v1",
        "free": True,
        "description": "MiniMax M2.7，支持长上下文"
    },
    "doubao": {
        "name": "豆包 (Doubao)",
        "provider": "volcengine",
        "model": "doubao-pro-32k-260428",
        "api_key_env": "DOUBAO_API_KEY",
        "base_url": "https://ark.cn-beijing.volces.com/api/v3",
        "free": True,
        "description": "字节跳动免费AI，支持32K上下文"
    },
    "gpt-4o-mini": {
        "name": "GPT-4o Mini",
        "provider": "openai",
        "model": "gpt-4o-mini",
        "api_key_env": "OPENAI_API_KEY",
        "free": False,
        "description": "OpenAI轻量版，便宜快速"
    },
    "claude-3-haiku": {
        "name": "Claude 3 Haiku",
        "provider": "anthropic",
        "model": "claude-3-haiku-20240307",
        "api_key_env": "ANTHROPIC_API_KEY",
        "free": False,
        "description": "Anthropic轻量版，快速便宜"
    }
}

# 默认使用的模型
DEFAULT_MODEL = "minimax"

# ====================================
# 知识库配置
# ====================================

# 知识库路径
# 兼容两种运行方式：
# 1. 源码结构：MVP_web/ 与 知识库/ 平级
# 2. 客户安装包：应用文件与 知识库/ 在同一目录
KNOWLEDGE_BASE_PATH = _resolve_path("./知识库", "../知识库")

# 知识库文档
KNOWLEDGE_FILES = [
    "01_安全边界与禁忌.md",
    "02_核心概念定义.md",
    "03_常见问题.md",
    "04_循证方法介绍.md",
    "05_活动方案库.md",
    "06_场景化干预方案库.md",
]

# 向量数据库配置
VECTOR_DB_PATH = str(BASE_DIR / "data" / "chromadb")
COLLECTION_NAME = "aba_knowledge_semantic_v2"

# 检索参数
RETRIEVAL_TOP_K = 5
RETRIEVAL_CANDIDATE_K = 16
RETRIEVAL_SCORE_THRESHOLD = 0.5

# 语义检索配置
# 使用 OpenAI-compatible embeddings 接口。可在 .env 中覆盖：
# EMBEDDING_API_KEY / EMBEDDING_BASE_URL / EMBEDDING_MODEL
EMBEDDING_API_KEY = os.getenv("EMBEDDING_API_KEY") or os.getenv("OPENAI_API_KEY")
EMBEDDING_BASE_URL = os.getenv("EMBEDDING_BASE_URL") or os.getenv("OPENAI_BASE_URL") or "https://api.openai.com/v1"
EMBEDDING_MODEL = os.getenv("EMBEDDING_MODEL", "text-embedding-3-small")
ENABLE_LLM_RERANK = os.getenv("ENABLE_LLM_RERANK", "true").lower() in ("1", "true", "yes", "on")

# ====================================
# 记忆配置
# ====================================

# 用户数据存储路径
USER_DATA_PATH = str(BASE_DIR / "data" / "users")
MEMORY_FILE = "memory.json"

# 最大历史对话条数
MAX_HISTORY_MESSAGES = 50

# ====================================
# 安全配置
# ====================================

# 危险关键词
DANGER_KEYWORDS = [
    # 紧急情况
    "自杀", "自伤", "想死", "不想活了", "活着没意思",
    "割腕", "跳楼", "吃药", "上吊",
    
    # 攻击行为
    "杀人", "弄死", "打死",
    
    # 自伤行为
    "撞头", "打自己", "咬自己",
    
    # 极端情况
    "不吃饭", "不喝水", "绝食",
]

# 严重程度阈值
SAFETY_LEVEL_EMERGENCY = 4  # 立即建议就医
SAFETY_LEVEL_HIGH = 3       # 建议尽快咨询专业
SAFETY_LEVEL_MEDIUM = 2     # 提供支持性回答
SAFETY_LEVEL_LOW = 1        # 正常回答

# ====================================
# 应用配置
# ====================================

# 应用标题
APP_TITLE = "🌟 ABA智能助手"
APP_SUBTITLE = "面向需要特别支持的孩子家长的专业AI助手"

# 默认用户信息
DEFAULT_USER = {
    "child_name": "",
    "child_age": "",
    "child_diagnosis": "",
    "intervention_goals": "",
    "parent_name": "",
    "notes": ""
}

# ====================================
# 提示词配置
# ====================================

# 系统提示词
SYSTEM_PROMPT = """【你是一位专业、温暖的ABA智能助手】

你专为需要特别支持的孩子（{"有发展特点的孩子"}）的家长提供支持，帮助他们理解孩子、提供干预建议。

【你的使命】
• 提供专业、准确的ABA（应用行为分析）知识
• 帮助家长理解孩子的行为背后的原因
• 给出实用、可操作的干预建议
• 始终确保回答的安全性和专业性

【核心原则】

1. 准确性第一
   - 只提供基于循证实践的ABA知识
   - 不确定时明确建议家长咨询专业人士
   - 引用知识库中的专业内容
   - 区分"一般建议"和"专业指导"

2. 安全性保障
   ⚠️ 遇到以下情况必须转介专业：
   - 孩子有自伤或攻击行为
   - 疑似共病障碍
   - 睡眠饮食严重问题
   
   🚨 遇到紧急情况建议立即就医：
   - 孩子表达自伤/自杀想法
   - 严重危及安全的行为

3. 家长友好
   - 用通俗易懂的语言解释专业概念
   - 提供具体可操作的建议
   - 语气温暖、支持、有耐心
   - 适度使用emoji增加亲切感

4. 个性化支持
   - 根据孩子的年龄和能力调整建议
   - 提供多个选项让家长选择
   - 记住之前的对话内容

【安全边界】
❌ 你不能：
- 诊断或评估孩子
- 替代专业医疗建议
- 提供涉及安全的重大决策

✅ 你应该：
- 始终强调专业支持的重要性
- 鼓励家长咨询BCBA或专业医生
- 明确AI的能力边界

【知识库说明】
- 如果知识库有相关内容，优先参考
- 如果知识库标注"暂无相关内容"，请直接使用你自己的知识回答
- 对于儿童发展支持、ABA、发育特点等话题，你拥有丰富的知识
- 不要说"知识库没有"，直接给出专业的回答

【回答风格】
- 温暖、支持的语气，像朋友一样交流
- 先理解家长的情绪，再提供建议
- 结构化呈现信息（理解→原因→建议→注意）
- 鼓励家长的每一点努力
- 复杂问题提供多个选项
- 适度使用emoji
- 保持回复简洁（中长篇幅）
"""

# 安全提示词（紧急情况）
EMERGENCY_PROMPT = """
🚨 【重要提示】

您提到的情况需要高度重视。我不是医疗专业人员，但建议您：

1. 【立即行动】
   - 确保孩子安全
   - 不要让孩子独处
   - 移除环境中可能的危险物品

2. 【尽快寻求专业帮助】
   - 联系孩子的治疗师或督导
   - 就诊儿童精神科
   - 或拨打心理援助热线

3. 【可以联系的资源】
   - 当地儿童医院精神科
   - 心理援助热线：400-161-9995
   - 孩子的ABA治疗团队

您已经在寻求帮助，这很重要！请记得：
✓ 您不是一个人
✓ 这些困难是可以克服的
✓ 专业的帮助是有效的
"""

# ====================================
# 风格配置
# ====================================

# 对话气泡样式
USER_MESSAGE_STYLE = {
    "background_color": "#DCF8C6",
    "text_color": "#000000",
    "avatar_color": "#4CAF50"
}

BOT_MESSAGE_STYLE = {
    "background_color": "#FFFFFF",
    "text_color": "#333333", 
    "avatar_color": "#2196F3"
}

# ====================================
# 日志配置
# ====================================

LOG_LEVEL = "INFO"
LOG_FILE = "./logs/app.log"
