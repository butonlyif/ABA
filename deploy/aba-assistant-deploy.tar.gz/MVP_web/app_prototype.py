"""
====================================
ABA智能助手 - 统一主应用
====================================

包含：
- AI助手问答
- 孩子档案管理
- 任务清单
- 进展记录
- 报告中心
"""

import streamlit as st
import time
from datetime import datetime
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from config import (
    APP_TITLE, APP_SUBTITLE, DEFAULT_USER,
    SYSTEM_PROMPT, EMERGENCY_PROMPT, DEFAULT_MODEL, AI_MODELS,
    USER_DATA_PATH, MEMORY_FILE, KNOWLEDGE_BASE_PATH
)
from knowledge_base import KnowledgeBase
from agent import ABAAgent
from safety import SafetyChecker
from deep_memory import memory_system
from deep_memory_extended import ChildProfileManager
from report_generator import ReportGenerator, ProgressChart
from ui_styles import apply_custom_styles
from charts import (
    create_category_pie_chart,
    create_progress_line_chart,
    create_concern_bar_chart,
    create_activity_heatmap,
    create_category_comparison_chart
)
from ai_report_generator import SmartReportGenerator
from task_generator import TaskGenerator

st.set_page_config(
    page_title=APP_TITLE,
    page_icon="🌟",
    layout="wide",
    initial_sidebar_state="expanded"
)

DEFAULT_USER_INFO = {
    "child_name": "",
    "child_age": "",
    "diagnosis": "",
    "intervention_goals": ""
}

def get_child_manager() -> ChildProfileManager:
    if "child_manager" not in st.session_state:
        st.session_state.child_manager = ChildProfileManager(USER_DATA_PATH)
    return st.session_state.child_manager

def format_ai_response(content: str):
    """格式化AI回复内容，优化排版"""
    if not content:
        return

    content = content.replace("\n\n", "\n")

    if content.startswith("# "):
        st.markdown(content)
        return
    elif "```" in content:
        st.markdown(content)
        return

    lines = content.split("\n")
    has_content = False

    for line in lines:
        line = line.strip()
        if not line:
            continue
        has_content = True
        if line.startswith("**") and line.endswith("**") and line.count("**") == 2:
            st.markdown(f"**{line[2:-2]}**")
        elif line.startswith("-"):
            st.markdown(f"- {line[1:].strip()}")
        elif line[0].isdigit() and "." in line[:3]:
            st.markdown(line)
        else:
            st.markdown(line)

    if not has_content:
        st.markdown(content)

def render_sidebar():
    """渲染侧边栏"""
    with st.sidebar:
        st.markdown("## 🌟 ABA智能助手")
        st.markdown("---")

        if not st.session_state.get("logged_in", False):
            tab1, tab2 = st.tabs(["登录", "注册"])

            with tab1:
                login_username = st.text_input("用户名", key="login_user")
                login_password = st.text_input("密码", type="password", key="login_pass")
                if st.button("登录", use_container_width=True):
                    success, msg = memory_system.login(login_username, login_password)
                    if success:
                        st.session_state.logged_in = True
                        saved_profile = memory_system.get_user_info()
                        if saved_profile and saved_profile.get('user_info'):
                            st.session_state.user_info = saved_profile['user_info']
                        else:
                            st.session_state.user_info = DEFAULT_USER_INFO.copy()
                        st.success(f"✅ 登录成功！")
                        st.rerun()
                    else:
                        st.error(msg)

            with tab2:
                reg_username = st.text_input("用户名", key="reg_user")
                reg_password = st.text_input("密码", type="password", key="reg_pass")
                reg_password2 = st.text_input("确认密码", type="password", key="reg_pass2")
                if st.button("注册", use_container_width=True):
                    if reg_password != reg_password2:
                        st.error("两次密码不一致")
                    else:
                        success, msg = memory_system.register(reg_username, reg_password)
                        if success:
                            st.session_state.logged_in = True
                            st.session_state.user_info = DEFAULT_USER_INFO.copy()
                            st.success("✅ 注册成功！")
                            st.rerun()
                        else:
                            st.error(msg)

            st.markdown("---")
        else:
            st.success(f"✅ 已登录: {memory_system.current_username}")

            user_info = st.session_state.get("user_info", DEFAULT_USER_INFO)

            st.markdown("---")

            if st.button("🚪 退出登录", use_container_width=True):
                st.session_state.logged_in = False
                st.session_state.current_view = "chat"
                st.session_state.messages = []
                memory_system.current_user_id = None
                memory_system.current_username = None
                st.rerun()

        st.markdown("---")
        st.markdown("### 🤖 AI引擎")

        available_models = {}
        for model_id, model_config in AI_MODELS.items():
            api_key = os.getenv(model_config.get("api_key_env", ""))
            if api_key:
                available_models[model_id] = f"{model_config['name']} ✅"

        if not available_models:
            st.warning("未配置任何AI引擎")
        else:
            model_options = list(available_models.keys())
            model_labels = [available_models[m] for m in model_options]

            current_model = st.session_state.get("current_ai_model", DEFAULT_MODEL)
            if current_model not in model_options:
                current_model = model_options[0]

            selected = st.selectbox(
                "选择AI引擎",
                options=model_options,
                format_func=lambda x: available_models[x],
                index=model_options.index(current_model),
                key="ai_model_selector"
            )
            st.session_state.current_ai_model = selected

        st.markdown("---")
        st.markdown("### 📱 功能导航")

        if st.button("💬 AI助手", use_container_width=True, type="primary"):
            st.session_state.current_view = "chat"
            st.rerun()

        if st.session_state.get("logged_in", False):
            if st.button("👶 孩子档案", use_container_width=True):
                st.session_state.current_view = "profile"
                st.rerun()

            if st.button("✅ 任务清单", use_container_width=True):
                st.session_state.current_view = "tasks"
                st.rerun()

            if st.button("📊 进展记录", use_container_width=True):
                st.session_state.current_view = "progress"
                st.rerun()

            if st.button("📈 数据看板", use_container_width=True):
                st.session_state.current_view = "dashboard"
                st.rerun()

            if st.button("📝 报告中心", use_container_width=True):
                st.session_state.current_view = "reports"
                st.rerun()

        st.markdown("---")
        st.markdown("### ℹ️ 关于")
        st.caption("ABA智能助手 v2.0")

    user_context = {
        "child_name": st.session_state.get("user_info", {}).get("child_name", ""),
        "child_age": st.session_state.get("user_info", {}).get("child_age", ""),
        "diagnosis": st.session_state.get("user_info", {}).get("diagnosis", ""),
        "intervention_goals": st.session_state.get("user_info", {}).get("intervention_goals", "")
    }

    return user_context

def initialize_session_state():
    if "logged_in" not in st.session_state:
        st.session_state.logged_in = False
    if "user_info" not in st.session_state:
        st.session_state.user_info = DEFAULT_USER_INFO.copy()
    if "messages" not in st.session_state:
        st.session_state.messages = []
    if "current_view" not in st.session_state:
        st.session_state.current_view = "chat"
    if "safety_checker" not in st.session_state:
        st.session_state.safety_checker = SafetyChecker()

    current_model = st.session_state.get("current_ai_model", DEFAULT_MODEL)
    agent_model = st.session_state.get("agent_model", None)

    if "agent" not in st.session_state or agent_model != current_model:
        st.session_state.agent_model = current_model
        try:
            st.session_state.agent = ABAAgent(model_name=current_model)
        except Exception as e:
            st.session_state.agent = None

def render_chat_view():
    """渲染AI聊天界面"""
    st.markdown(f'<p class="main-title">{APP_TITLE}</p>', unsafe_allow_html=True)
    st.markdown(f'<p class="subtitle">{APP_SUBTITLE}</p>', unsafe_allow_html=True)

    if not st.session_state.messages:
        welcome_msg = """
        👋 **欢迎使用ABA智能助手！**

        我是一位专业、温暖的AI助手，专为需要特别支持的孩子家长提供支持。

        **我可以帮助你：**
        • 了解ABA基础知识
        • 解答关于孩子行为的疑惑
        • 提供实用的家庭干预建议
        • 分享日常干预的技巧

        **请先在左侧填写孩子的情况**，这样我可以给你更个性化的建议！

        **快捷问题示例：**
        - 什么是正强化？
        - 孩子发脾气怎么办？
        - 怎么教孩子说话？
        - 孩子2岁还不会说话，正常吗？
        """
        st.info(welcome_msg)

    for message in st.session_state.messages:
        if message["role"] == "user":
            with st.chat_message("user"):
                st.markdown(message["content"])
        else:
            with st.chat_message("assistant"):
                if message.get("safety_level", 0) >= 3:
                    if message["safety_level"] >= 4:
                        st.warning(EMERGENCY_PROMPT)
                    else:
                        st.info("⚠️ **温馨提示**：以下情况建议咨询专业人员")

                format_ai_response(message["content"])

    st.markdown("---")

    user_input = st.chat_input("输入你的问题...")

    if user_input:
        st.session_state.messages.append({
            "role": "user",
            "content": user_input,
            "timestamp": datetime.now().isoformat()
        })

        with st.chat_message("user"):
            st.markdown(user_input)

        safety_result = st.session_state.safety_checker.check(user_input)

        with st.chat_message("assistant"):
            with st.spinner("🤔 思考中..."):
                try:
                    user_context = {
                        "child_name": "",
                        "child_age": "",
                        "diagnosis": "",
                        "intervention_goals": ""
                    }

                    if st.session_state.logged_in:
                        user_id = memory_system.current_user_id
                        manager = get_child_manager()
                        children = manager.get_children(user_id)
                        if children:
                            child = children[0]
                            user_context["child_name"] = child.get("name", "")
                            user_context["child_age"] = child.get("birth_date", "")[:10] if child.get("birth_date") else ""
                            user_context["diagnosis"] = child.get("diagnosis", "")
                            user_context["intervention_goals"] = child.get("intervention_goals", "")

                    if st.session_state.logged_in and st.session_state.agent:
                        rag_context = memory_system.get_context_for_rag(user_input)
                        user_context["rag_context"] = rag_context

                    if safety_result["level"] >= 4:
                        response = EMERGENCY_PROMPT
                        st.warning("🚨 检测到紧急信号，已提供紧急帮助信息")
                    else:
                        response = st.session_state.agent.generate_response(
                            user_input=user_input,
                            context=user_context,
                            safety_level=safety_result["level"]
                        )

                        if safety_result["level"] >= 2:
                            st.info("⚠️ **温馨提示**：如果情况持续或加重，建议咨询专业医生或BCBA。")

                    st.session_state.messages.append({
                        "role": "assistant",
                        "content": response,
                        "safety_level": safety_result["level"],
                        "timestamp": datetime.now().isoformat()
                    })

                    format_ai_response(response)

                    if st.session_state.logged_in:
                        memory_system.save_conversation(role="user", content=user_input)
                        memory_system.save_conversation(
                            role="assistant",
                            content=response,
                            metadata={"safety_level": safety_result["level"]}
                        )

                except Exception as e:
                    st.error(f"抱歉，发生了错误：{str(e)}")
                    response = "抱歉，我现在遇到了一些问题，请稍后再试。"
                    st.session_state.messages.append({
                        "role": "assistant",
                        "content": response,
                        "timestamp": datetime.now().isoformat()
                    })
                    format_ai_response(response)

def render_child_profile_page():
    """孩子档案管理页面"""
    st.markdown('<h2 class="page-title">👶 孩子档案管理</h2>', unsafe_allow_html=True)

    manager = get_child_manager()
    user_id = memory_system.current_user_id

    tab1, tab2 = st.tabs(["📋 档案列表", "➕ 添加档案"])

    with tab1:
        children = manager.get_children(user_id)

        if not children:
            st.info("暂无孩子档案，请添加")
        else:
            for child in children:
                with st.container():
                    col1, col2 = st.columns([3, 1])
                    with col1:
                        st.markdown(f"### 👤 {child['name']}")
                        st.markdown(f"**年龄**: {child.get('birth_date', '未填写')}")
                    with col2:
                        pass

                    with st.expander("查看详情"):
                        st.markdown(f"**诊断**: {child.get('diagnosis', '未填写')}")
                        st.markdown(f"**诊断时间**: {child.get('diagnosis_date', '未填写')}")
                        st.markdown(f"**干预目标**: {child.get('intervention_goals', '未填写')}")
                        st.markdown(f"**备注**: {child.get('notes', '无')}")
                        st.markdown(f"**创建时间**: {child.get('created_at', '未知')[:10] if child.get('created_at') else '未知'}")

                    st.markdown("---")

                    col_btn = st.columns([1, 1, 1, 1])
                    with col_btn[0]:
                        if st.button(f"✏️ 编辑", key=f"edit_{child['child_id']}"):
                            st.session_state[f"editing_child_{child['child_id']}"] = True
                    with col_btn[1]:
                        if st.button(f"✅ 任务", key=f"tasks_{child['child_id']}"):
                            st.session_state.current_view = "tasks"
                            st.session_state.selected_child_id = child['child_id']
                            st.rerun()
                    with col_btn[2]:
                        if st.button(f"📊 进展", key=f"progress_{child['child_id']}"):
                            st.session_state.current_view = "progress"
                            st.session_state.selected_child_id = child['child_id']
                            st.rerun()
                    with col_btn[3]:
                        if st.button(f"🗑️ 删除", key=f"delete_{child['child_id']}", type="primary"):
                            success, msg = manager.delete_child(child['child_id'], user_id)
                            if success:
                                st.success("✅ 档案已删除")
                                st.rerun()
                            else:
                                st.error(f"❌ {msg}")
                    st.markdown("---")

    with tab2:
        with st.form("add_child_form"):
            name = st.text_input("孩子姓名 *", placeholder="请输入姓名")
            birth_date = st.date_input("出生日期", value=None)
            diagnosis = st.selectbox("诊断情况", ["", "自闭症", "发育迟缓", "感统失调", "语言发育迟缓", "其他"])
            diagnosis_date = st.date_input("诊断时间", value=None)
            intervention_goals = st.text_area("干预目标", placeholder="请描述当前的干预目标...")
            notes = st.text_area("备注", placeholder="其他补充信息...")

            if st.form_submit_button("➕ 添加档案", use_container_width=True):
                if name:
                    birth_date_str = birth_date.isoformat() if birth_date else None
                    diagnosis_date_str = diagnosis_date.isoformat() if diagnosis_date else None
                    success, msg, child_id = manager.add_child(
                        user_id=user_id,
                        name=name,
                        birth_date=birth_date_str,
                        diagnosis=diagnosis,
                        diagnosis_date=diagnosis_date_str,
                        intervention_goals=intervention_goals,
                        notes=notes
                    )
                    if success:
                        st.success("✅ 档案添加成功！")
                        st.rerun()
                    else:
                        st.error(f"❌ {msg}")
                else:
                    st.warning("请填写孩子姓名")

def render_task_list_page():
    """任务清单页面"""
    st.markdown('<h2 class="page-title">✅ 任务清单</h2>', unsafe_allow_html=True)

    manager = get_child_manager()
    user_id = memory_system.current_user_id
    task_generator = TaskGenerator()

    children = manager.get_children(user_id)
    if not children:
        st.info("📝 请先在「孩子档案」中添加孩子信息")
        return

    col_child = st.columns([2, 1])
    with col_child[0]:
        child_options = {c["child_id"]: c["name"] for c in children}
        selected_child_id = st.selectbox(
            "👶 选择孩子",
            options=list(child_options.keys()),
            format_func=lambda x: child_options[x],
            key="task_child_select"
        )
    with col_child[1]:
        st.markdown("<br>", unsafe_allow_html=True)
        if st.button("🔄 根据目标生成任务", use_container_width=True):
            child = next((c for c in children if c["child_id"] == selected_child_id), None)
            if child:
                goals = child.get("intervention_goals", "")
                suggested_tasks = task_generator.generate_initial_tasks(goals)

                added_count = 0
                for task in suggested_tasks:
                    success, msg, _ = manager.add_task(
                        child_id=selected_child_id,
                        user_id=user_id,
                        task_name=task["name"],
                        task_description=task.get("description", ""),
                        category=task.get("category", ""),
                        is_auto_generated=True
                    )
                    if success:
                        added_count += 1

                if added_count > 0:
                    st.success(f"✅ 已为您生成 {added_count} 个建议任务！")
                else:
                    st.info("任务生成完成（可能已有相同任务）")
                st.rerun()

    st.markdown("---")

    child = next((c for c in children if c["child_id"] == selected_child_id), None)
    if child and child.get("intervention_goals"):
        with st.expander("📋 当前干预目标"):
            st.write(child["intervention_goals"])

    tab1, tab2, tab3 = st.tabs(["📝 待完成", "✅ 已完成", "➕ 添加任务"])

    with tab1:
        st.markdown("#### 待完成的任务")
        pending_tasks = manager.get_tasks(selected_child_id, user_id, status="pending")

        if not pending_tasks:
            st.info("🎉 太棒了！所有任务都已完成！")

        for task in pending_tasks:
            with st.container():
                st.markdown(f"""
                <div class="task-card">
                    <div class="task-name">📌 {task['task_name']}</div>
                    <div class="task-desc">{task.get('task_description', '无描述')}</div>
                    <div class="task-meta">类别: {task.get('category', '未分类')} | {task.get('created_at', '')[:10]}</div>
                </div>
                """, unsafe_allow_html=True)

                col_fb = st.columns([1, 1, 2, 1])
                with col_fb[0]:
                    if st.button("✅ 做了", key=f"done_{task['task_id']}"):
                        success, msg = manager.update_task_feedback(
                            task['task_id'], user_id, "completed", "做了"
                        )
                        if success:
                            st.success("👍 记录成功！")
                            st.rerun()
                with col_fb[1]:
                    if st.button("❌ 没做", key=f"notdone_{task['task_id']}"):
                        success, msg = manager.update_task_feedback(
                            task['task_id'], user_id, "not_done", "没做"
                        )
                        if success:
                            st.info("📝 已记录")
                            st.rerun()
                with col_fb[2]:
                    effect = st.selectbox(
                        "效果",
                        ["效果好", "效果一般", "效果不好"],
                        key=f"effect_{task['task_id']}"
                    )
                with col_fb[3]:
                    st.markdown("")
                    if st.button("🗑️", key=f"del_task_{task['task_id']}"):
                        manager.delete_task(task['task_id'], user_id)
                        st.rerun()

                st.markdown("---")

    with tab2:
        st.markdown("#### 已完成任务")
        completed_tasks = manager.get_tasks(selected_child_id, user_id, status=None)

        completed = [t for t in completed_tasks if t["status"] in ["completed", "not_done"]]
        if not completed:
            st.info("暂无已完成的任务")
        else:
            for task in completed:
                status_icon = "✅" if task["status"] == "completed" else "❌"
                feedback = task.get("feedback", "")
                st.markdown(f"""
                <div class="task-card completed">
                    <div class="task-name">{status_icon} {task['task_name']}</div>
                    <div class="task-desc">{task.get('task_description', '无描述')}</div>
                    <div class="task-meta">
                        反馈: {feedback} | {task.get('category', '未分类')} | {task.get('feedback_date', '')[:10] if task.get('feedback_date') else '未填写'}
                    </div>
                </div>
                """, unsafe_allow_html=True)

                col_act = st.columns([1, 1, 1])
                with col_act[0]:
                    if st.button(f"🔄 重新开始", key=f"redo_{task['task_id']}"):
                        manager.update_task_feedback(task['task_id'], user_id, "pending", None)
                        st.rerun()
                with col_act[1]:
                    st.markdown("")
                with col_act[2]:
                    if st.button(f"🗑️ 删除", key=f"del_task_done_{task['task_id']}"):
                        manager.delete_task(task['task_id'], user_id)
                        st.rerun()
                st.markdown("---")

    with tab3:
        st.markdown("#### 添加自定义任务")
        with st.form("add_task_form"):
            task_name = st.text_input("任务名称 *", placeholder="例如：桌面教学-命名练习")
            task_desc = st.text_area("任务描述", placeholder="描述具体怎么做...")
            category = st.selectbox(
                "类别",
                ["语言训练", "社交训练", "行为训练", "生活自理", "认知训练", "感统训练", "其他"]
            )

            if st.form_submit_button("➕ 添加任务"):
                if task_name:
                    success, msg, _ = manager.add_task(
                        child_id=selected_child_id,
                        user_id=user_id,
                        task_name=task_name,
                        task_description=task_desc,
                        category=category,
                        is_auto_generated=False
                    )
                    if success:
                        st.success("✅ 任务添加成功！")
                        st.rerun()
                    else:
                        st.error(f"❌ 添加失败: {msg}")
                else:
                    st.warning("请填写任务名称")

def render_progress_page():
    """进展记录页面"""
    st.markdown('<h2 class="page-title">📊 进展记录</h2>', unsafe_allow_html=True)

    manager = get_child_manager()
    user_id = memory_system.current_user_id

    children = manager.get_children(user_id)
    if not children:
        st.info("📝 请先在「孩子档案」中添加孩子信息")
        return

    child_options = {c["child_id"]: c["name"] for c in children}
    selected_child_id = st.selectbox(
        "👶 选择孩子",
        options=list(child_options.keys()),
        format_func=lambda x: child_options[x],
        key="progress_child_select"
    )

    child = manager.get_child(selected_child_id, user_id)

    tab1, tab2 = st.tabs(["📝 记录进展", "📋 历史记录"])

    with tab1:
        with st.form("progress_form"):
            st.markdown("#### 记录孩子进展")

            col1, col2 = st.columns(2)
            with col1:
                category = st.selectbox(
                    "类别 *",
                    ["行为", "技能", "社交", "语言", "情绪", "自理", "其他"]
                )
                metric_name = st.text_input("指标名称", placeholder="如：正确回应次数")
            with col2:
                value = st.text_input("数值", placeholder="如：5/10")
                log_date = st.date_input("日期")

            description = st.text_area("详细描述", placeholder="描述孩子今天的表现...")

            submitted = st.form_submit_button("💾 记录", use_container_width=True)

            if submitted:
                if category:
                    success, msg = manager.add_progress_log(
                        child_id=selected_child_id,
                        user_id=user_id,
                        category=category,
                        metric_name=metric_name,
                        value=value,
                        description=description,
                        log_date=log_date.isoformat()
                    )
                    if success:
                        st.success("✅ 进展记录成功！")
                        st.rerun()
                    else:
                        st.error(f"❌ {msg}")
                else:
                    st.warning("请选择类别")

    with tab2:
        st.markdown("#### 历史记录")
        logs = manager.get_progress_logs(selected_child_id, user_id, limit=50)

        if not logs:
            st.info("暂无进展记录")
        else:
            for log in logs:
                with st.expander(f"📌 {log['log_date'][:10]} - {log['category']}"):
                    st.markdown(f"**指标**: {log['metric_name'] or '未填写'}")
                    st.markdown(f"**数值**: {log['value'] or '未填写'}")
                    st.markdown(f"**描述**: {log['description'] or '无'}")
                    if log.get('tags'):
                        st.markdown(f"**标签**: {' '.join(['🏷️' + t for t in log['tags']])}")

                    col_del = st.columns([3, 1])
                    with col_del[0]:
                        if st.button(f"🗑️ 删除此记录", key=f"del_log_{log['log_id']}"):
                            success, msg = manager.delete_progress_log(log['log_id'], user_id)
                            if success:
                                st.success("✅ 删除成功")
                                st.rerun()
                            else:
                                st.error(f"❌ {msg}")

def render_data_dashboard():
    """数据看板页面"""
    st.markdown('<h2 class="page-title">📈 数据看板</h2>', unsafe_allow_html=True)

    manager = get_child_manager()
    user_id = memory_system.current_user_id

    children = manager.get_children(user_id)
    if not children:
        st.info("📝 请先在「孩子档案」中添加孩子信息")
        return

    child_options = {c["child_id"]: c["name"] for c in children}
    selected_child_id = st.selectbox(
        "👶 选择孩子",
        options=list(child_options.keys()),
        format_func=lambda x: child_options[x],
        key="dashboard_child_select"
    )

    summary = manager.get_progress_summary(selected_child_id, user_id)
    logs = manager.get_progress_logs(selected_child_id, user_id, limit=100)

    col1, col2, col3, col4 = st.columns(4)
    with col1:
        st.metric("总记录数", summary.get("total_logs", 0))
    with col2:
        st.metric("本周记录", summary.get("this_week_logs", 0))
    with col3:
        st.metric("记录类别", summary.get("unique_categories", 0))
    with col4:
        st.metric("对话数量", summary.get("total_conversations", 0))

    st.markdown("---")

    if logs:
        chart = ProgressChart.generate_category_chart(logs)
        if chart and chart != "暂无数据":
            with st.expander("📊 类别分布图"):
                st.text(chart)
    else:
        st.info("暂无数据")

def render_report_center_page():
    """报告中心页面"""
    st.markdown('<h2 class="page-title">📝 报告中心</h2>', unsafe_allow_html=True)

    manager = get_child_manager()
    user_id = memory_system.current_user_id
    generator = ReportGenerator(manager)

    children = manager.get_children(user_id)
    if not children:
        st.info("📝 请先在「孩子档案」中添加孩子信息")
        return

    child_options = {c["child_id"]: c["name"] for c in children}
    selected_child_id = st.selectbox(
        "👶 选择孩子",
        options=list(child_options.keys()),
        format_func=lambda x: child_options[x],
        key="report_child_select"
    )

    tab1, tab2 = st.tabs(["📋 报告列表", "✨ 生成报告"])

    with tab1:
        reports = manager.get_reports(selected_child_id, user_id)

        if not reports:
            st.info("暂无报告，请先生成")
        else:
            for report in reports:
                with st.expander(f"📄 {report['title']} ({report['report_type']})"):
                    st.markdown(f"**类型**: {report['report_type']}")
                    st.markdown(f"**时间范围**: {report['period_start'][:10] if report['period_start'] else 'N/A'} ~ {report['period_end'][:10] if report['period_end'] else 'N/A'}")
                    st.markdown(f"**生成时间**: {report['created_at'][:10] if report['created_at'] else '未知'}")
                    if report.get('summary'):
                        st.markdown(f"**摘要**: {report['summary']}")

                    col_act = st.columns([1, 1, 1])
                    with col_act[0]:
                        if st.button(f"👁️ 查看详情", key=f"view_{report['report_id']}"):
                            st.session_state.viewing_report_id = report['report_id']
                    with col_act[1]:
                        pass
                    with col_act[2]:
                        if st.button(f"🗑️ 删除", key=f"del_report_{report['report_id']}"):
                            success, msg = manager.delete_report(report['report_id'], user_id)
                            if success:
                                st.success("✅ 报告已删除")
                                st.rerun()
                            else:
                                st.error(f"❌ {msg}")

        if st.session_state.get("viewing_report_id"):
            report = manager.get_report(st.session_state.viewing_report_id, user_id)
            if report:
                st.markdown("---")
                st.markdown(f"### 📄 {report['title']}")
                st.markdown(report.get('content', '无内容'))

                if st.button("← 返回列表"):
                    st.session_state.viewing_report_id = None
                    st.rerun()

    with tab2:
        st.markdown("#### 选择报告类型")

        col_report = st.columns(3)
        with col_report[0]:
            report_type = st.radio(
                "报告类型",
                ["周报", "月报", "阶段报告"],
                label_visibility="collapsed"
            )

        generator = ReportGenerator(manager)

        if st.button("✨ 生成报告", use_container_width=True):
            with st.spinner("🤔 正在生成报告..."):
                if report_type == "周报":
                    result = generator.generate_weekly_report(selected_child_id, user_id)
                elif report_type == "月报":
                    result = generator.generate_monthly_report(selected_child_id, user_id)
                else:
                    result = generator.generate_progress_report(selected_child_id, user_id)

                if result["success"]:
                    st.success("✅ 报告生成成功！")
                    st.markdown("---")
                    st.markdown("### 📝 报告预览")
                    st.markdown(result.get("content", ""))
                else:
                    st.error(f"❌ 报告生成失败: {result.get('error', '未知错误')}")

def main():
    """主函数"""
    apply_custom_styles()
    initialize_session_state()
    user_context = render_sidebar()

    st.markdown("---")

    current_view = st.session_state.get("current_view", "chat")

    if not st.session_state.get("logged_in", False):
        st.session_state.current_view = "chat"
        current_view = "chat"

    if current_view == "chat":
        render_chat_view()
    elif current_view == "profile":
        render_child_profile_page()
    elif current_view == "tasks":
        render_task_list_page()
    elif current_view == "progress":
        render_progress_page()
    elif current_view == "dashboard":
        render_data_dashboard()
    elif current_view == "reports":
        render_report_center_page()

if __name__ == "__main__":
    main()
