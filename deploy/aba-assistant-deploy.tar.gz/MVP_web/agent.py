"""
====================================
ABA智能助手 - Agent模块
====================================

负责AI对话和响应生成
支持多种AI模型和工具调用
"""

import os
import json
import re
from typing import Dict, List, Optional, Any
from datetime import datetime
import requests

try:
    from config import (
        SYSTEM_PROMPT, AI_MODELS, RETRIEVAL_TOP_K, RETRIEVAL_CANDIDATE_K,
        SAFETY_LEVEL_LOW, ENABLE_LLM_RERANK
    )
except ImportError:
    SYSTEM_PROMPT = ""
    AI_MODELS = {}
    RETRIEVAL_TOP_K = 5
    RETRIEVAL_CANDIDATE_K = 16
    ENABLE_LLM_RERANK = True

# 部署到公网时启用的每日总调用预算兜底（防 API Key 被刷爆）。
# 本地运行不受影响：只在到达阈值时抛错。
try:
    from budget_guard import check_and_increment, BudgetExceededError
except ImportError:
    def check_and_increment():  # type: ignore
        pass
    class BudgetExceededError(RuntimeError):  # type: ignore
        pass


def search_web(query: str) -> str:
    """
    搜索网络获取信息
    优先使用Google，Google不可用时使用Bing

    Args:
        query: 搜索关键词

    Returns:
        搜索结果的摘要文本
    """
    headers = {
        'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
    }

    # 首先尝试 Google
    google_result = _google_search(query, headers)
    if google_result:
        return google_result

    # Google 不可用时使用 Bing
    print("Google 不可用，使用 Bing 搜索...")
    return _bing_search(query, headers)


def _google_search(query: str, headers: dict) -> str:
    """使用 Google 搜索"""
    try:
        search_query = f"{query} 自闭症 OR ABA OR 儿童发育"
        url = f"https://www.google.com/search?q={requests.utils.quote(search_query)}"

        response = requests.get(url, headers=headers, timeout=8)

        if response.status_code != 200:
            return None

        content = response.text

        # Google 搜索结果解析
        title_pattern = r'<h3[^>]*class="[^"]*"[^>]*>([^<]+)</h3>'
        titles = re.findall(title_pattern, content)

        link_pattern = r'<h3[^>]*class="[^"]*"[^>]*>.*?<a[^>]*href="([^"]+)"[^>]*>'
        links = re.findall(link_pattern, content, re.DOTALL)

        if titles and len(titles) > 0:
            result_text = f"## 搜索结果：{query}\n\n"
            for i, (title, link) in enumerate(zip(titles[:5], links[:5])):
                clean_title = re.sub(r'<[^>]+>', '', title)
                clean_link = link.split('&')[0] if link else ''
                if clean_title and len(clean_title) > 5:
                    result_text += f"**{i+1}. {clean_title}**\n"
                    result_text += f"来源：{clean_link}\n\n"
            result_text += "\n---\n*搜索结果来源：Google*\n"
            return result_text[:1500]

        return None

    except Exception as e:
        print(f"Google 搜索失败: {e}")
        return None


def _bing_search(query: str, headers: dict) -> str:
    """使用 Bing 搜索"""
    try:
        search_query = f"{query} 自闭症 OR ABA OR 儿童发育"
        url = f"https://www.bing.com/search?q={requests.utils.quote(search_query)}"

        response = requests.get(url, headers=headers, timeout=10)

        if response.status_code != 200:
            return f"未找到关于'{query}'的搜索结果"

        content = response.text

        title_pattern = r'<h2[^>]*><a[^>]*href="[^"]*"[^>]*>([^<]+)</a></h2>'
        titles = re.findall(title_pattern, content)

        link_pattern = r'<h2[^>]*><a[^>]*href="([^"]+)"[^>]*>'
        links = re.findall(link_pattern, content)

        if titles and len(titles) > 0:
            result_text = f"## 搜索结果：{query}\n\n"
            for i, (title, link) in enumerate(zip(titles[:5], links[:5])):
                clean_title = re.sub(r'<[^>]+>', '', title)
                if clean_title and len(clean_title) > 5:
                    result_text += f"**{i+1}. {clean_title}**\n"
                    result_text += f"来源：{link}\n\n"
            result_text += "\n---\n*搜索结果来源：Bing*\n"
            return result_text[:1500]

        return f"未找到关于'{query}'的搜索结果"

    except Exception as e:
        return f"搜索失败: {str(e)}"


# 可用的工具定义
AVAILABLE_TOOLS = [
    {
        "type": "function",
        "function": {
            "name": "search_web",
            "description": "全网信息检索功能。当用户询问的问题超出知识库范围，或需要最新信息时使用此工具搜索相关网页内容。",
            "parameters": {
                "type": "object",
                "properties": {
                    "query": {
                        "type": "string",
                        "description": "搜索关键词，应该是简洁的搜索查询"
                    }
                },
                "required": ["query"]
            }
        }
    }
]


class ABAAgent:
    """ABA智能助手Agent"""

    def __init__(
        self,
        knowledge_base=None,
        model_name: str = "minimax"
    ):
        """
        初始化Agent

        Args:
            knowledge_base: 知识库实例
            model_name: 使用的模型名称
        """
        self.knowledge_base = knowledge_base
        self.model_name = model_name
        self.model_config = AI_MODELS.get(model_name, AI_MODELS.get("minimax"))
        self.conversation_history = []

        # 工具函数映射
        self.tool_functions = {
            "search_web": search_web
        }

        # 初始化AI客户端
        self._init_client()

    def _init_client(self):
        """初始化AI客户端"""
        self.client = None

        provider = self.model_config.get("provider", "")

        try:
            if provider == "openai":
                api_key = os.getenv("MINIMAX_API_KEY") or os.getenv("OPENAI_API_KEY")
                if api_key:
                    from openai import OpenAI
                    base_url = self.model_config.get("base_url", "https://api.minimaxi.com/v1")
                    self.client = OpenAI(api_key=api_key, base_url=base_url)
                    self._use_openai_compatible = True

            elif provider == "anthropic":
                from anthropic import Anthropic
                api_key = os.getenv("ANTHROPIC_API_KEY")
                if api_key:
                    self.client = Anthropic(api_key=api_key)

            elif provider == "volcengine":
                api_key = os.getenv("DOUBAO_API_KEY")
                if api_key:
                    from openai import OpenAI
                    self.client = OpenAI(
                        api_key=api_key,
                        base_url=self.model_config.get("base_url", "https://ark.cn-beijing.volces.com/api/v3")
                    )
                    self._use_openai_compatible = True

            else:
                print(f"⚠️ 不支持的AI提供商: {provider}")

        except Exception as e:
            print(f"⚠️ AI客户端初始化失败: {e}")

    def generate_response(
        self,
        user_input: str,
        context: Dict,
        safety_level: int = SAFETY_LEVEL_LOW
    ) -> str:
        """
        生成AI响应

        Args:
            user_input: 用户输入
            context: 上下文信息（用户信息、对话历史等）
            safety_level: 安全级别

        Returns:
            AI生成的响应
        """
        # 构建提示词
        prompt = self._build_prompt(user_input, context)

        # 如果有知识库，添加相关知识
        if self.knowledge_base and hasattr(self.knowledge_base, 'search'):
            search_results = self.knowledge_base.search(user_input, top_k=RETRIEVAL_CANDIDATE_K)
            if not search_results and hasattr(self.knowledge_base, "get_semantic_rerank_candidates"):
                search_results = self.knowledge_base.get_semantic_rerank_candidates()
            search_results = self._rerank_knowledge(user_input, search_results, RETRIEVAL_TOP_K)
            if search_results:
                knowledge_context = self.knowledge_base.format_context(search_results)
                prompt = prompt.replace(
                    "[知识库内容]",
                    f"\n\n## 参考知识库内容：\n{knowledge_context}\n\n如果知识库内容与问题相关，请优先参考上述内容。\n"
                )
            else:
                prompt = prompt.replace(
                    "[知识库内容]",
                    "\n\n## 参考知识库内容：\n（知识库中暂无相关内容，请使用search_web工具搜索网络获取信息）\n"
                )
        else:
            prompt = prompt.replace(
                "[知识库内容]",
                "\n\n## 参考知识库内容：\n（知识库未加载，请使用search_web工具搜索网络获取信息）\n"
            )

        if context.get("rag_context"):
            prompt += f"\n\n{context['rag_context']}\n"

        # 调用AI（带工具支持）
        try:
            check_and_increment()  # 每日总调用预算兜底
            response = self._call_ai_with_tools(prompt)
            return response
        except BudgetExceededError as e:
            return f"⚠️ {e}"
        except Exception as e:
            return f"抱歉，我遇到了一些问题: {str(e)}\n\n请稍后再试，或检查API配置是否正确。"

    def _rerank_knowledge(
        self,
        query: str,
        candidates: List[Dict],
        top_k: int
    ) -> List[Dict]:
        """Use the current LLM to rerank semantic retrieval candidates."""
        if not candidates:
            return []

        if not ENABLE_LLM_RERANK or not self.client:
            return candidates[:top_k]

        provider = self.model_config.get("provider", "")
        if provider not in ("openai", "volcengine"):
            return candidates[:top_k]

        if len(candidates) > RETRIEVAL_CANDIDATE_K:
            shortlist = []
            batch_size = RETRIEVAL_CANDIDATE_K
            for start in range(0, len(candidates), batch_size):
                batch = candidates[start:start + batch_size]
                shortlist.extend(self._rerank_knowledge_batch(query, batch, max(2, top_k // 2)))
            return self._rerank_knowledge_batch(query, shortlist, top_k)

        return self._rerank_knowledge_batch(query, candidates, top_k)

    def _rerank_knowledge_batch(
        self,
        query: str,
        candidates: List[Dict],
        top_k: int
    ) -> List[Dict]:
        """Rerank one manageable batch of candidate chunks."""
        if not candidates:
            return []

        compact_items = []
        for idx, item in enumerate(candidates, 1):
            content = item.get("content", "").replace("\n", " ")
            compact_items.append({
                "id": idx,
                "title": item.get("title", ""),
                "source": item.get("source", ""),
                "content": content[:700]
            })

        prompt = f"""你是ABA知识库检索重排器。请根据用户问题，从候选知识片段中选出最相关、最能支持回答的片段。

用户问题：
{query}

候选片段：
{json.dumps(compact_items, ensure_ascii=False)}

要求：
1. 优先选择能直接回答问题、提供可操作步骤、包含安全边界的片段。
2. 不要选择只是碰巧出现相同词但语义无关的片段。
3. 最多返回 {top_k} 个片段 id。
4. 只输出JSON，不要解释。

输出格式：
{{"ids": [1, 3, 5]}}"""

        try:
            response = self.client.chat.completions.create(
                model=self.model_config.get("model", ""),
                messages=[
                    {"role": "system", "content": "你只负责知识库语义重排，必须输出合法JSON。"},
                    {"role": "user", "content": prompt}
                ],
                temperature=0,
                max_tokens=200
            )
            text = response.choices[0].message.content or ""
            match = re.search(r'\{.*\}', text, re.DOTALL)
            if not match:
                return candidates[:top_k]

            data = json.loads(match.group())
            ids = data.get("ids", [])
            selected = []
            seen = set()
            for item_id in ids:
                try:
                    index = int(item_id) - 1
                except (TypeError, ValueError):
                    continue
                if 0 <= index < len(candidates) and index not in seen:
                    selected.append(candidates[index])
                    seen.add(index)
                if len(selected) >= top_k:
                    break

            return selected or candidates[:top_k]
        except Exception as e:
            print(f"知识库重排失败: {e}")
            return candidates[:top_k]

    def _build_prompt(self, user_input: str, context: Dict) -> str:
        """构建提示词"""

        # 构建用户信息上下文
        user_context = ""
        if context.get("child_name"):
            user_context += f"- 孩子姓名：{context['child_name']}\n"
        if context.get("child_age"):
            user_context += f"- 孩子年龄：{context['child_age']}\n"
        if context.get("child_diagnosis"):
            user_context += f"- 诊断情况：{context['child_diagnosis']}\n"
        if context.get("intervention_goals"):
            user_context += f"- 当前干预目标：{context['intervention_goals']}\n"

        # 构建对话历史
        history_context = ""
        if context.get("conversation_history"):
            history_context = "\n\n## 对话历史：\n"
            for msg in context["conversation_history"][-5:]:
                role = "家长" if msg["role"] == "user" else "AI助手"
                history_context += f"- {role}：{msg['content'][:100]}...\n"

        # 组装完整提示词
        prompt = f"""{SYSTEM_PROMPT}

## 当前用户信息：
{user_context if user_context else "（暂无详细信息）"}

## 用户当前问题：
{user_input}

{history_context}

## 相关知识库内容：
[知识库内容]

请根据以上信息，提供专业、温暖、有帮助的回答。
"""

        return prompt

    def _call_ai_with_tools(self, prompt: str) -> str:
        """
        调用AI，支持工具调用

        Args:
            prompt: 提示词

        Returns:
            AI最终响应
        """
        if not self.client:
            return self._generate_fallback_response(prompt)

        provider = self.model_config.get("provider", "")
        model = self.model_config.get("model", "")

        # 构建消息
        messages = [
            {"role": "system", "content": "你是一位专业、温暖的ABA智能助手，专注于帮助自闭症儿童的家长。请用中文回答。"},
            {"role": "user", "content": prompt}
        ]

        # 最大工具调用次数（防止无限循环）
        max_turns = 3
        turn = 0

        try:
            while turn < max_turns:
                turn += 1

                if provider == "openai" or provider == "volcengine":
                    response = self.client.chat.completions.create(
                        model=model,
                        messages=messages,
                        tools=AVAILABLE_TOOLS if turn == 1 else None,
                        tool_choice="auto" if turn == 1 else None,
                        temperature=0.7,
                        max_tokens=2000
                    )

                    message = response.choices[0].message

                    # 检查是否有工具调用
                    if message.tool_calls:
                        # 添加AI的回复到对话历史
                        messages.append({
                            "role": "assistant",
                            "content": message.content,
                            "tool_calls": [
                                {"id": tc.id, "function": {"name": tc.function.name, "arguments": tc.function.arguments}}
                                for tc in message.tool_calls
                            ]
                        })

                        # 执行工具调用
                        for tool_call in message.tool_calls:
                            tool_name = tool_call.function.name
                            tool_args = json.loads(tool_call.function.arguments)

                            print(f"🔍 执行工具: {tool_name}, 参数: {tool_args}")

                            if tool_name in self.tool_functions:
                                result = self.tool_functions[tool_name](**tool_args)
                            else:
                                result = f"未知工具: {tool_name}"

                            # 添加工具结果到对话
                            messages.append({
                                "role": "tool",
                                "tool_call_id": tool_call.id,
                                "content": result
                            })

                        # 继续对话，让AI基于工具结果生成回复
                        continue

                    else:
                        # 没有工具调用，返回最终回复
                        return message.content or "抱歉，我没有找到相关信息。"

                elif provider == "anthropic":
                    response = self.client.messages.create(
                        model=model,
                        max_tokens=2000,
                        messages=[
                            {"role": "user", "content": prompt}
                        ]
                    )
                    return response.content[0].text

            # 超过最大调用次数
            return "抱歉，搜索时间过长，请稍后再试。"

        except Exception as e:
            print(f"AI调用失败: {e}")
            return self._generate_fallback_response(prompt)

    def _generate_fallback_response(self, prompt: str) -> str:
        """生成后备响应（当AI不可用时）"""
        # 简单的关键词匹配响应
        prompt_lower = prompt.lower()

        # 关键词响应映射
        keyword_responses = {
            ("正强化", "强化"): """**什么是正强化？** ✨

正强化是ABA中最基本、最重要的概念之一。

**简单解释：**
当孩子做出某个行为后，立即给他喜欢的东西（强化物），这个行为就会增加。

**举个例子：**
孩子说了"苹果"，你立即给他一块苹果 → 孩子以后更愿意说话

**关键要点：**
✓ 强化物必须是孩子真正喜欢的
✓ 强化要在行为发生后**立即**给
✓ 一开始要**每次**都强化
✓ 之后可以逐渐变成间歇强化

**常见强化物：**
- 食物：饼干、糖果（慎用）
- 活动：玩游戏、看动画片
- 社会性：拥抱、夸奖、"太棒了！"

**注意事项：**
1. 不要用零食作为唯一强化物
2. 结合口头表扬效果更好
3. 观察孩子的偏好，选择最有效的强化物

想了解更多强化相关的知识吗？""",

            ("发脾气", "哭", "闹"): """**孩子发脾气怎么办？** 😢

发脾气是自闭症孩子常见的挑战，处理需要耐心。

**发脾气的阶段：**

1. **开始阶段（预防）**
   - 保持冷静
   - 分散注意力
   - 提前预告

2. **升级阶段**
   - 不要争论
   - 减少关注
   - 保护安全

3. **高潮阶段**
   - 确保安全
   - 等待消退
   - 不要让步

4. **结束阶段**
   - 平静互动
   - 恢复正常
   - 可以简单讨论

**关键原则：**
✓ 保持冷静是最好的策略
✓ 不要在发脾气时让步（会让情况更糟）
✓ 安全第一
✓ 脾气后要恢复正常

**预防更重要：**
- 了解孩子发脾气的常见触发点
- 提前调整条件
- 保持一致的作息
- 充分预告变化

想了解更多处理行为问题的方法吗？""",

            ("说话", "语言", "沟通"): """**怎么教孩子说话？** 🗣️

语言发展是很多家长关心的问题，这里有一些建议。

**从表达需求开始：**

1. **创造机会**
   - 把孩子想要的东西放在看得见但拿不到的地方
   - 等待孩子表达

2. **提示和强化**
   - 孩子不说话时可以提示
   - 立即强化正确的表达

3. **从简单开始**
   - 单词 → 词组 → 句子
   - 每次只学一个目标

**记住：**
✓ 每个孩子发展速度不同
✓ 不说话≠不想说话
✓ 手势、表情也是沟通方式
✓ 尽早评估，明确孩子情况

**鼓励小贴士：**
🌟 日常生活中多说话
🌟 描述孩子感兴趣的东西
🌟 在不同情境重复同一词汇
🌟 立即强化孩子的每一次尝试

需要了解更具体的语言训练方法吗？"""
        }

        # 匹配关键词
        for keywords, response in keyword_responses.items():
            if any(kw in prompt_lower for kw in keywords):
                return response

        # 默认响应
        return """**你好！** 👋

谢谢你的提问！我是ABA智能助手，专注于帮助自闭症儿童的家长。

**我可以帮助你：**
• 了解ABA基础知识
• 解答关于孩子行为的疑惑
• 提供实用的家庭干预建议

请告诉我你关心的问题，我会尽力帮助你！

💡 如果遇到知识库没有的问题，我会尝试联网搜索获取更多信息。
"""
